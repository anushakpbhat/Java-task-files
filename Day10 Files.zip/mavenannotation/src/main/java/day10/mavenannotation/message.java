package day10.mavenannotation;



import org.springframework.stereotype.Component;


@Component
public class message {

	
	/*public message() {
		System.out.println("Inside Constructor");
	}*/
	 void display() {
		System.out.println("Inside method");
	}
}
