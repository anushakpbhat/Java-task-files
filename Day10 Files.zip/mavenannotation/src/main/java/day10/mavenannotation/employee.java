package day10.mavenannotation;

import org.springframework.beans.factory.annotation.Autowired;

public class employee {
	
	
	@Autowired
	
	salary sal;

	public salary getSal() {
		return sal;
	}

	public void setSal(salary sal) {
		this.sal = sal;
	}
	void displaysal() {
		sal.display();
	}

}
