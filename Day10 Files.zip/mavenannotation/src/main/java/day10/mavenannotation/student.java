package day10.mavenannotation;

import org.springframework.beans.factory.annotation.Autowired;

public class student {
	@Autowired
	 address add;

	public address getAdd() {
		return add;
	}

	public void setAdd(address add) {
		this.add = add;
	}

	
	 void displayadd()
	 {
		 add.display();
	 }
}
