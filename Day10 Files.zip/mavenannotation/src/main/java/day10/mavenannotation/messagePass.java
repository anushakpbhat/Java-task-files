package day10.mavenannotation;

import org.springframework.beans.factory.annotation.Autowired;

public class messagePass {
	
	@Autowired
	message msg;

	public message getMsg() {
		return msg;
	}

	public void setMsg(message msg) {
		this.msg = msg;
	}
	
	void displaymsg()
	{
		msg.display();
	}
	
	

}
