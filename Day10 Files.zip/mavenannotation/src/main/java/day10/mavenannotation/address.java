package day10.mavenannotation;

import java.util.Scanner;

public class address {

	
	/*public address() {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter address");
		String ss=s.next();
		System.out.println(ss);
	}*/
	 void display() {
		System.out.println("Coorg");
	}
}
