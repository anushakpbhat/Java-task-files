package day10.mavenannotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("NewFile1.xml");
       /* messagePass pass=(messagePass)context.getBean("msgpass");
        pass.displaymsg();*/
        
       /* student stuu=(student)context.getBean("stu");
        stuu.displayadd();*/
        
        employee empp=(employee)context.getBean("emp");
        empp.displaysal();
        
    }
}
