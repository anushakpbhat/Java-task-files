package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employeee;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/api")

public class EmployeeController {
	
	
	@Autowired
	EmployeeService service;
	
	
	@GetMapping("/Getemployees")
	
	public List<Employeee>getAllEmployees()
	{
		return service.getAllEmployees();
	}

	
	@PostMapping("/employee")
	public void saveEmployeee(@RequestBody Employeee ee)
	{
		service.saveEmployeee(ee);
	}
	
	
	
	@PostMapping("/deleteemployeee/{id}")
	public void deleteEmployeee(@PathVariable String id)
	{
		service.deleteEmployeee(id);
	}
	
}













