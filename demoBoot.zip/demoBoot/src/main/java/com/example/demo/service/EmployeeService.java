package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employeee;
import com.example.demo.repository.EmployeeRepository;


@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository repository;
	
	
	public List<Employeee>getAllEmployees()
	{
		return repository.findAll();
	}
    
	public void saveEmployeee(Employeee e)
	{
		repository.save(e);
	}
	
	public void deleteEmployeee(String id)
	{
		repository.deleteById(id);
	}
}
