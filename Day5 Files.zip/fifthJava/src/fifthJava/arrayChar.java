package fifthJava;

public class arrayChar {

	public static void main(String[] args) {
		 char vowels[]= {'a','e','i','o','u'};

		    for(int i=0;i<vowels.length;i++)
		    {
		        System.out.println(vowels[i]);
		    }
		    
		    
		    String s[]= {"anu","sha"};
		    for(int i=0;i<s.length;i++)
		    {
		    	System.out.println(s[i]);
		    }
		    
		    
		    int si[]= {100,101};
		    for(int i=0;i<s.length;i++)
		    {
		    	System.out.println(si[i]);
		    }

	}

}
