/**
 * 
 */
/**
 * @author 00005731
 *
 */
module seventhJavaa {
}