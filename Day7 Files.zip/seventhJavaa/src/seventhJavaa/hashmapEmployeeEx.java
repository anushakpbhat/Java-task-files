package seventhJavaa;

import java.util.HashMap;
import java.util.Map.Entry;

public class hashmapEmployeeEx {

	public static void main(String[] args) {
		HashMap<String,employee> map=new HashMap<>();
		System.out.println("Employee  Name  Id  salary");
		employee e1=new employee("anusha", "01", "Rs.20000");
		employee e2=new employee("akshatha", "02", "Rs.60000");
		employee e3=new employee("anjali", "03", "Rs.40000");
		map.put("employee1", e1);
		map.put("employee2", e2);
		map.put("employee3", e3);
		for(Entry<String, employee> me:map.entrySet()) 
		{
			System.out.println(me.getKey()+" "+me.getValue().name+" "+me.getValue().id+" "+me.getValue().salary);
		}

	}

}

class employee{
	String name,id,salary;

	public employee(String name, String id, String salary) {
		super();
		this.name = name;
		this.id = id;
		this.salary = salary;

	}

}
