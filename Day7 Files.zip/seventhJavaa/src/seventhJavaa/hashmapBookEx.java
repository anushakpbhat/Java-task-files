package seventhJavaa;

import java.util.HashMap;
import java.util.Map.Entry;

public class hashmapBookEx {

	public static void main(String[] args) {
		HashMap<String,book> map=new HashMap<>();
		System.out.println("Book  Name  Id  Price");
		book b1=new book("xyz","01","Rs.200");
		book b2=new book("abc","02","Rs.600");
		book b3=new book("bhg","03","Rs.400");
		map.put("book1", b1);
		map.put("book2", b2);
		map.put("book3", b3);
		for(Entry<String, book> me:map.entrySet()) 
		{
			System.out.println(me.getKey()+" "+me.getValue().name+" "+me.getValue().id+" "+me.getValue().price);
		}

	}

}

class book{
	String name,id,price;

	public book(String name, String id, String price) {
		super();
		this.name = name;
		this.id = id;
		this.price = price;
	}
	
}