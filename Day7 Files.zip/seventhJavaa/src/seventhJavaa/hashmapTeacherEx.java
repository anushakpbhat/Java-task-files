package seventhJavaa;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class hashmapTeacherEx {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		HashMap<Integer,teacher> map=new HashMap<>();
		System.out.println("Enter the number");
		int n=s.nextInt();
		for(int i=0;i<=n;i++) {
		System.out.println("enter the name,id,class of techer1");
		String name=s.next();
		String id=s.next();
		String classs=s.next();
		
		teacher t=new teacher(name,id,classs);
		map.put(i, t);
        i++;
		}
		for(Entry<Integer, teacher> me:map.entrySet()) 
		{
			System.out.println(me.getKey()+" "+me.getValue().name+" "+me.getValue().id+" "+me.getValue().classs);
		}

	}

}

class teacher{
	String name,id,classs;

	public teacher(String name, String id, String classs) {
		super();
		this.name = name;
		this.id = id;
		this.classs = classs;

	}

}

