package seventhJavaa;

import java.util.ArrayList;
import java.util.Scanner;

public class evenOddPrimeArraylistEx {

	public static void main(String[] args) {
		ArrayList<Integer>list=new ArrayList<>();
		for(int i=0;i<=20;i++) {
			list.add(i);
		}
		ArrayList<Integer>even=new ArrayList<>();
		ArrayList<Integer>odd=new ArrayList<>();
		ArrayList<Integer>prime=new ArrayList<>();
		 int flag=0;
		 for(int a:list)
		 {
			 if(a%2==0)
			 {
				 even.add(a);
			 }
			 else 
			 {
				 odd.add(a);
				 for(int j=2;j<=(a/2);j++) {
					 if(a%j!=0){
						 flag=1;
						 break;
					 }} 
				if(flag==1) {
					prime.add(a);
					}
			 }}
				 System.out.println("Even numbers are:"+even);
				 System.out.println("odd numbers are:"+odd);
				 System.out.println("prime numbers are:"+prime);
			 }
		
		}
	







