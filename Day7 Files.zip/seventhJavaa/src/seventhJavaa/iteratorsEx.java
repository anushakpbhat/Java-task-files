package seventhJavaa;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.ListIterator;
import java.util.Set;


public class iteratorsEx {


	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<>();
		list.add("one");
		list.add("two");
		list.add("three");
		list.add("four");
		System.out.println(list);
		ListIterator<String> i=list.listIterator();               //listIterator / iterator
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		while(i.hasPrevious())
		{
			System.out.println(i.previous());
		}
		

		
		
		
		Set<String> set=new HashSet<>();                          //set 
		set.add("one");
		set.add("two");
		set.add("three");
		set.add("four");
		System.out.println(set);
	}

}
