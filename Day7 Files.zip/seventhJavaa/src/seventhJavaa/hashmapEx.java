package seventhJavaa;

import java.util.HashMap;
import java.util.Map.Entry;


public class hashmapEx {

	public static void main(String[] args) {
     HashMap<Integer,String> map=new HashMap<>();
	 map.put(1, "anu");
	 map.put(2, "anusha");
	 System.out.println(map);
		
		
     HashMap<String,String> exp=new HashMap<>();
     exp.put("color1", "Red");
     exp.put("color2", "Blue");
     exp.put("color3", "White");
     System.out.println(exp);
     
     HashMap<String,Integer> exp2=new HashMap<>();
     exp2.put("Java", 80);
     exp2.put("php", 85);
     exp2.put("python", 90);
     System.out.println(exp2);
		
     HashMap<Integer,String> exp3=new HashMap<>();
	
	 exp3.put(1, "anusha");
	 exp3.put(2, "anushakp");
	 exp3.put(3, "anushabhat");
	 for(Entry<Integer, String>  me:exp3.entrySet())
	 {
		System.out.println(me.getKey()+" "+me.getValue());
	 }
	
	 }

}
