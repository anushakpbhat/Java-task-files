package seventhJavaa;

import java.util.ArrayList;

public class arraylistEx {

	public static void main(String[] args) {
		ArrayList<String>list=new ArrayList<>();
		list.add("php");
		list.add("java");
		ArrayList<String>listt=new ArrayList<>();
		listt.add("python");
		listt.add("C");
		list.addAll(listt);
		 for(String x:list)
		 {
			 System.out.println(x);
		 }

	}

}
