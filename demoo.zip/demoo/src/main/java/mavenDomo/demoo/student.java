package mavenDomo.demoo;

public class student {
     String name,rollno;

	public student(String name, String rollno) {
		super();
		this.name = name;
		this.rollno = rollno;
	}
	
	
	
	void display()
	{
		System.out.println("Name:"+name+"\nRollNo:"+rollno);
	}
}

