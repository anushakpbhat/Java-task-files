package mavenDomo.demoo;

public class book {
	String id,publisher,price;

	public book(String id, String publisher, String price) {
		super();
		this.id = id;
		this.publisher = publisher;
		this.price = price;
	}
	
	void display()
	{
		System.out.println("Id:"+id+"\nPublisher:"+publisher+"\nPrice:"+price );
	}
	

}
