package mavenDomo.demoo;

public class customer {
	String name,id,phone,add;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}
	
	void display()
	{
		System.out.println("Name:"+name+"\nId:"+id+"\nAddress:"+add+"\nPhone:"+phone);
	}

}
