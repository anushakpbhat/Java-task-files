package mavenDomo.demoo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class test {

	public static void main(String[] args) {
    ApplicationContext context=new ClassPathXmlApplicationContext("NewFiles.xml");
		
        System.out.println("STUDENT");
		student s=(student)context.getBean("s1");
		s.display();
		                                 System.out.println();//spacing purpose
		System.out.println("BOOK");
		book s2=(book)context.getBean("s2");
		s2.display();
		                                 System.out.println();//spacing purpose
		System.out.println("EMPLOYEE");
		employee s3=(employee)context.getBean("s3");
		s3.display();
		
		                                 System.out.println();//spacing purpose
		System.out.println("CUSTOMER");
		customer c=(customer)context.getBean("s4");
		c.display();

	}

}
