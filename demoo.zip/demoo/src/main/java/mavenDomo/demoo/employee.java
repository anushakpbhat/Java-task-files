package mavenDomo.demoo;

public class employee {
	String id,sal,add,name;

	public employee(String id, String sal, String add, String name) {
		super();
		this.id = id;
		this.sal = sal;
		this.add = add;
		this.name = name;
	}
	
	void display()
	{
		System.out.println("Id:"+id+"\nSalary:"+sal+"\nAddress:"+add+"\nName:"+name );
	}
	

}
