package day8;

import java.util.ArrayList;

public class lambdaEx {

	public static void main(String[] args) {            //simple lambda example
		cal c=()->
		{
			System.out.println("working!!!");
		};
        c.add();
        
        
        
        adv a=(int x,int y)->                           //adding two numbers using lambda
        {
        	System.out.println(+x+y);
        };
      a.add(5, 5);
      
      
      ArrayList<Integer> list=new ArrayList<>();        //arrayList using lambda
      list.add(1);
      list.add(2);
      list.add(3);
      list.add(4);
      list.add(5);
      list.forEach(
      (n)->System.out.println(n));
	}

}



interface cal
{
	void add();
}

interface adv
{
	void add(int a,int b);
}