package day8;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class methodsAnyStream {

	public static void main(String[] args) {
		 Stream<String> stream = Stream.of("one", "two", "three", "four");
	        boolean match = stream.anyMatch(s -> s.contains("four"));                         //anyMatch()
	        System.out.println(match);

	        
	        
	        List<Integer> numbers = List.of(1, 2, 3, 4, 5, 6);
			
	        List<Integer> evenNumbers = numbers.stream().filter(x -> x % 2 == 0)                //filter()
	        		                                    .collect(Collectors.toList());          //collect()
	        System.out.println(evenNumbers); 
	        
	        
	        
	        
	        Stream<String> stream1 = Stream.of("Geeks", "for");
	        Stream<String> stream2 = Stream.of("GeeksQuiz", "GeeksforGeeks");
	        Stream.concat(stream1, stream2)
            .forEach(element -> System.out.println(element));                                    //concat()
	       


	        long count = IntStream.of(1,2,3,4,5,6,7,8,9)
                    .count();
            System.out.printf("There are %d integers in the stream ", count);                     //count()
            
	}

}
