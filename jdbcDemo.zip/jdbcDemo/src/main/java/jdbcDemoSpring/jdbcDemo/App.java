package jdbcDemoSpring.jdbcDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
        ApplicationContext context=new ClassPathXmlApplicationContext("config.xml");
        employeeOperations op=(employeeOperations)context.getBean("operationdemo");
        Employee el=new Employee();
        el.setEmail("anusha@kp");
        el.setName("anu");
        el.setId("12");
        el.setSal("12345");
        
        int result= op.insert(el);
        System.out.println(result);
    	
    	
        
    }
}
