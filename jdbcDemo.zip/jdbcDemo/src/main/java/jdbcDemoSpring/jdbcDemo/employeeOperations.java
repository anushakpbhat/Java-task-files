package jdbcDemoSpring.jdbcDemo;

import org.springframework.jdbc.core.JdbcTemplate;

public class employeeOperations {
           JdbcTemplate jdbcTemplate;
           
           
     
           
//           
//           public JdbcTemplate getJdbcTemplate() {
//			return jdbcTemplate;
//		}

		public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
			this.jdbcTemplate = jdbcTemplate;
		}

		int insert(Employee emp)
           {
        	   String email=emp.getEmail();
        	   String name=emp.getName();
        	   String id=emp.getId();
        	   String sal=emp.getSal();
        	   
        	   String query="insert into Employee values('"+email+"','"+name+"','"+id+"','"+sal+"')";
        	   int result=jdbcTemplate.update(query);
        	   
        	   return result;
           }
}
