package newPack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("NewFile.xml");
		
		
		
		System.out.println("STUDENT");
		Student s=(Student)context.getBean("s1");
		s.display(); 
		                                         System.out.println();//spacing purpose
		                                         
		System.out.println("BOOK");
		book s2=(book)context.getBean("s2");
		s2.display();          
		                                         System.out.println();
		System.out.println("CUSTOMER");
		employee s3=(employee)context.getBean("s3");
		s3.display();
		

	}

}
