package newPack;

public class employee {
	String id,sal,add,name;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSal() {
		return sal;
	}

	public void setSal(String sal) {
		this.sal = sal;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	void display()
	{
		System.out.println("EmployeeId:"+id);
		System.out.println("Salary:"+sal);
		System.out.println("Address:"+add);
		System.out.println("Name:"+name);
	}

}
