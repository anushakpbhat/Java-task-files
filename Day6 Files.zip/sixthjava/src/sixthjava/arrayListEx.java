package sixthjava;

import java.util.ArrayList;

public class arrayListEx {

	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<>();      //string
		list.add("anu");
		list.add("sha");
		list.add("kp");
		for(String x:list)
		{
			System.out.println(x);
		}
		ArrayList<Integer> num=new ArrayList<>();      //integer
		num.add(1);
		num.add(2);
		num.add(3);
		num.add(4);
		System.out.println(num); //prints in array format
		for(Integer n:num)          //prints in list format
		{
			System.out.println(n);
		}
	}

}
