package sixthjava;

import java.util.ArrayList;

public class arrayListExp3 {

	public static void main(String[] args) {
		ArrayList<Student> list=new ArrayList<>();
		Student s1=new Student("anusha","present");
		Student s2=new Student("bhat","present");
		list.add(s1);
		list.add(s2);
		for(Student  x:list)
		{
			System.out.println(x.name+"  "+x.attendance);
		}
		

	}

}

class Student{
	String name;
	String attendance;
	public Student(String name, String attendance) {
		this.name = name;
		this.attendance = attendance;
	}
	
}