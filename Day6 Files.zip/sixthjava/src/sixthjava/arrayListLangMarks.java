package sixthjava;

import java.util.ArrayList;

public class arrayListLangMarks {

	public static void main(String[] args) {
		ArrayList<Ratings> list=new ArrayList<>();
		System.out.println("Languages R/10");
		System.out.println();//spacing purpose
		Ratings s1=new Ratings("Java   ",9);
		Ratings s2=new Ratings("Php    ",10);
		Ratings s3=new Ratings("C      ",10);
		Ratings s4=new Ratings("C++    ",10);
		list.add(s1);
		list.add(s2);
		list.add(s3);
		list.add(s4);
		for(Ratings  x:list)
		{
			System.out.println(x.language+ "   "+x.marks);
		}
	}
}

class Ratings{
	String language;
	int marks;
	public Ratings(String language, int marks) {
		super();
		this.language = language;
		this.marks = marks;
	}
	
	}	

