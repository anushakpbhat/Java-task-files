package sixthjava;

import java.util.ArrayList;
import java.util.Scanner;

public class arrayBookEx {

	public static void main(String[] args) {

		
		Scanner s=new Scanner(System.in);
		String name;int id,price;String author;
		ArrayList<book> list=new ArrayList<>();
		System.out.println("Enter no. of books");
		int b=s.nextInt();
		for(int i=0;i<b;i++) {
		System.out.println("Enter bookName,id,price,author");
		name=s.next();
		id=s.nextInt();
		price=s.nextInt();
		author=s.next();
		book x=new book(name,id,price,author);
		list.add(x);
		}
		System.out.println("Name\t Id\t Price\t Author\t");
		for(book x:list)
		{
			System.out.println(x.name+ "  \t "+x.id+ "  \t "+x.price+ " \t  "+x.author);
		}
	}
}

class book{
	String name,author;
	int id,price;
	public book(String name,  int id, int price,String author) {
		super();
		this.name = name;
		this.id = id;
		this.price = price;
		this.author = author;
	}
	
	}


