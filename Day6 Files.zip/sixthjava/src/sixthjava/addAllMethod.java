package sixthjava;

import java.util.ArrayList;

public class addAllMethod {

	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<>();    
		System.out.println("First array");
		list.add("anu");
		list.add("sha");
		list.add("kp");
		for(String x:list)
		{
			System.out.println(x);
		}
		ArrayList<String> num=new ArrayList<>();  
		System.out.println("Second array");
		num.add("bhu");
		num.add("bhf");
		num.add("bhu");
		num.add("nju");
		for(String n:num)       
		{
			System.out.println(n);	
		}
		System.out.println();//spacing purpose
		boolean res=num.isEmpty();                         //isEmpty method
		if(res==true) {
			System.out.println("List is empty");
		}
		else
		{
			System.out.println("List is not empty");
		}
		System.out.println();//spacing purpose
		
		list.addAll(num);
		System.out.println("The added arraylist ");          //addAll method
		for(String x:list) {
			System.out.println(x);
		}
		System.out.println();//spacing purpose
		
		list.clear();                                       //clear method
		System.out.println(list);

	}
}
