package sixthjava;

import java.util.ArrayList;

public class studentArrayList {

	public static void main(String[] args) {
		ArrayList<stud> list=new ArrayList<>();
		System.out.println("Name   Marks1   Marks2     Marks3");
		System.out.println();//spacing purpose
		stud s1=new stud("anu","100/500","300/500","500/500");
		stud s2=new stud("sha","100/500","200/500","400/500");
		stud s3=new stud("akp","100/500","300/500","400/500");
		stud s4=new stud("skp","300/500","500/500","200/500");
		list.add(s1);
		list.add(s2);
		list.add(s3);
		list.add(s4);
		for(stud x:list)
		{
			System.out.println(x.name+ "   "+x.marks1+ "   "+x.marks2+ "   "+x.marks3);
		}
	}
}

class stud{
	String name,marks1,marks2,marks3;
	public stud(String name, String marks1,String marks2,String marks3) {
		super();
		this.name =  name;
		this.marks1 = marks1;
		this.marks2 = marks2;
		this.marks3 = marks3;
	}

	}

