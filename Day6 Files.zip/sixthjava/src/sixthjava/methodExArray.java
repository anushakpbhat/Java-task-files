package sixthjava;

import java.util.ArrayList;

public class methodExArray {

	public static void main(String[] args) {
	   ArrayList<Integer> num=new ArrayList<>();      
		System.out.println("Array");
		num.add(1);
		num.add(2);
		num.add(3);
		num.add(4);
		for(Integer n:num)         
		{
			System.out.println(n);
			
		}
		System.out.println("Get element number is "+num.get(1));          //get method
		num.remove(3);                                                    //remove method
		System.out.println(num);
		num.removeAll(num);                                              //removeAll method
		System.out.println(num);
		
	
	}
}
