package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@SpringBootApplication
public class DemoBoot2Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(DemoBoot2Application.class, args);
	}
	
	
	
	@Autowired
	EmployeeRepository repository;
	
	@Override
	public void run(String...args)throws Exception
	{
		this.repository.save(new Employee("anu","an@an","1","10000"));
		this.repository.save(new Employee("anusha","as@as","2","20000"));
		this.repository.save(new Employee("bhat","bt@bt","3","30000"));
	}

}
