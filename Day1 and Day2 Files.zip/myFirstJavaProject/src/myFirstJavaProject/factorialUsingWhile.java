package myFirstJavaProject;

public class factorialUsingWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//while
		int i,fact=1;
		int num=3;
		i=1;
		while(i<=num)
		{
			fact=fact*i;
			i++;
		}
		System.out.println("Factorial of "+num+"  is:" +fact);
		
		
		
		//do while
		int n,facts=1;
		int nums=3;
		n=1;
		do
		{
			facts=facts*n;
			n++;
		}
		while(n<=num);
		System.out.println("Factorial of "+nums+"  is:" +facts);
		
		

	}

}
