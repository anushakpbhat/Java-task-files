package myFirstJavaProject;

public class table {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//while
		int num=4;
		int i=1;
		while(i<=10)
		{
			System.out.println(num*i);
			i++;
		}
		                    System.out.println();//Spacing purpose
    
		//do while
		int n=5;
		int c=1;
		do {
			System.out.println(n*c);
			c++;
		}
		while(c<=10);
		
		
		
	}
	
	
	

}
