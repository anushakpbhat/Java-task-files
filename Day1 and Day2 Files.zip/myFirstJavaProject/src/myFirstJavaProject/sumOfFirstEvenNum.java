package myFirstJavaProject;

public class sumOfFirstEvenNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Sum of first 100 even numbers
		
		int sum=0,c;
		for(c=2;c<=100;c++)
		{
			if(c%2==0) {
				sum=sum+c;	
			}
			
		}
		System.out.println("The sum of first 100 even numbers is:"+sum);
		

	}

}
