package myFirstJavaProject;

public class areaofsquare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Area of square
		
		int s=25;
		float areaaa=s*s;
		System.out.println("Area of square is:"+areaaa);

	}

}
