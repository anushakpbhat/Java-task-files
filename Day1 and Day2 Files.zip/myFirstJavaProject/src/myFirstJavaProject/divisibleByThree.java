package myFirstJavaProject;

public class divisibleByThree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Sum of numbers divisible by 3 and 9
		
		int sums=0,d;
		for(d=1;d<=1000; d++)
		{
			if(d%3==0 && d%9==0) {
				sums=sums+d;	
			}
			
		}
		System.out.println("The sum of numbers divisible by 3 and 9 is:"+sums);
		

	}

}
