package myFirstJavaProject;

public class electricalBill {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Electricity bill
	     int units=100;
	     if(units<=50)
	    	 System.out.println(" cost free");
	     else if(units>=50 && units<=100)
	     {
	    	 units=(units-50)*6;
	    	 System.out.println(" cost "+units);
	    	 }
          else if(units>=100 && units<=150) 
          {
       	   units=(units-100)*8+(50*6);
	    	 System.out.println(" cost "+units);
	    	 }
	     else 
	     {
	    	 units=(units-150)*9+(50*6)+(50*8);
  	    	 System.out.println(" cost "+units);
  	    	 }
	     

	}

}
