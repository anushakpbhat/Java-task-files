package myFirstJavaProject;

public class simpleinterest {

	public static void main(String[] args) {
		//Simple Interest
		
     	float p,r,t,si;
		p=1000;r=12;t=2;
		si=(p*t*r)/100;
		System.out.println("The simple interest is:"+si);
		

	}

}
