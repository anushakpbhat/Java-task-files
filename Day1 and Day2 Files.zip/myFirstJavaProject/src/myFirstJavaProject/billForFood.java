package myFirstJavaProject;
import java.util.Scanner;



public class billForFood {

	public static void main(String[] args) {
int run=1,sum=0,cof=100,tea=50,san=150,nor=150,sou=200,pul=300,par=350,b=1,l=2,d=3;
		Scanner sc=new Scanner(System.in);
		while(run==1) {
			System.out.println("Menu");
			System.out.println("1.Breakfast\n 2.Lunch\n 3.Dinner");
			System.out.println("Enter your choice(1,2,3)");
			int ch=sc.nextInt();
			
			if(ch>=1 && ch<=3)
			{
				while(b==ch) {
				if(ch==1) {
					System.out.println("1.Coffee");
					System.out.println("2.Tea");
					System.out.println("3.Sandwich");
					int c=sc.nextInt();
					if(c==1) 
					{
						sum+=ch;	
					}
					else if(c==2)
					{
						sum+=tea;
					}
					else {
						sum+=san;
					}
				}
			
			System.out.println("do you want to order more?press 1 for yes or else press 0");
			b=sc.nextInt();
			}
			
			while(l==ch) {
				if(ch==2) {
					System.out.println("1.North Meals");
					System.out.println("2.South meals   ");
					int in = sc.nextInt();
					if(in==1) {
						sum+=nor;
					}
					else  {
						sum+=sou;	
					}
			
				}

				System.out.println("do you want to order more?press 2 for yes or else press 0");
				l=sc.nextInt();
			}
			
		
		
			while(d==ch) {
				if(ch==3) {
					System.out.println("1.Pulav");
					System.out.println("2.Parata ");
					int inn = sc.nextInt();
					if(inn==1) {
						sum+=pul;
					}
					else  {
						sum+=par;	
					}
			
				}

				System.out.println("do you want to order more?press 3 for yes or else press 0");
				d=sc.nextInt();
			}
			
		}
		System.out.println("For main menu press 1 or press 0");
		run=sc.nextInt();
	   }
	    System.out.println("Please Pay the bill Rs:"+sum);
	    System.out.println("Thank you");
      }
	}
				
	
	
	
		
		