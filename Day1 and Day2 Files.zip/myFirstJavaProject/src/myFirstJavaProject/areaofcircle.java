package myFirstJavaProject;

public class areaofcircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Area of circle
		
		int radius=5;
		double areaa=Math.PI*radius*radius;
		System.out.println("Area of a circle is:"+areaa);

	}

}
