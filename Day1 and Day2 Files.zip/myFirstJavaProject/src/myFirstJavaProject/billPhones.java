package myFirstJavaProject;

public class billPhones {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Bill of calls
	     int calls=290;
	     if(calls<=100)
	    	 System.out.println("Call cost free");
	     else if(calls>=100 && calls<=200) {
	    	 calls=calls-100;
	    	 System.out.println("Call cost "+calls);}
          else if(calls>=200 && calls<=300) {
       	   calls=(calls-200)*2+100;
	    	 System.out.println("Call cost "+calls);}
	     else {
	    	 calls=(calls-300)*3+200+100;
  	    	 System.out.println("Call cost "+calls);}

	}

}
