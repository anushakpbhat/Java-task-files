package myFirstJavaProject;

public class greatestofthreenumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Greatest of three numbers
		 
		 int n1=20,n2=30,n3=10;
		 if(n1>n2&&n1>n3)
		 {
			 System.out.println("Num 1 is greater");
		 }
		 else if(n2>n3&&n2>n1)
		 {
			 System.out.println("Num 2 is greater");
		 }
		 else 
			 System.out.println("Num 3 is greater");

	}

}
