package myFirstJavaProject;

public class positiveOrnegative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Positive or negative
		 int num=-225;
		 if(num>=0)
			 System.out.println("number is positive");
		 else
			 System.out.println("Number is negative");

	}

}
