
package myFirstJavaProject;
import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		String name="Anusha",tech="Java";
		int age=21;
		
		System.out.println("Hello");
		System.out.println("My name is :" +name);
		System.out.println("I am learning :" +tech );
		System.out.println("My Age is :" +age);
		
	}

}


