package myFirstJavaProject;

import java.util.Scanner;

public class methods {
	
	void fact(int num)
	{
		int i,fact=1;
		for(i=1;i<=num;i++) {
			fact=fact*i;
		}
		System.out.println("Factorial of "+num+"  is:" +fact);
	}
	
	
	void sum(double x,double y)  //sum
	{
		
		System.out.println("sum:"+(x+y));
	}

	
	void areaCircle(float r)  //areaofcircle
	{
		
		System.out.println("Area of a circle is :"+(Math.PI*r*r));
	}
	
    void areaRectangle(float l,float b)  //areaofrectangle
    {
		
		System.out.println("Area of a rectangle is :"+(l*b));
	}
    

    void areaSquare(float s)     //areaofsquare
    {
	
	System.out.println("Area of a square is :"+(s*s));
    }
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		methods m= new methods();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number to print the factorial:");
		int i=s.nextInt();
		m.fact(i);
		                                  System.out.println();//spacing

		m.sum(34.5,665.76);
		
		                                System.out.println();//spacing
		System.out.println("Enter the radius to find the area of circle:");
		int a=s.nextInt();
		m.areaCircle(a);
		                                 System.out.println();//spacing
		
		System.out.println("enter length and breadth");
		int l=s.nextInt();
		int b=s.nextInt();
		m.areaRectangle(l, b);
		                                   System.out.println();//spacing
		
		System.out.println("Enter  side");
		int side1=s.nextInt();
		m.areaSquare(side1);
		

	}

}
