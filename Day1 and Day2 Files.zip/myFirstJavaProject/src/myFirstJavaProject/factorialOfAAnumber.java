package myFirstJavaProject;

public class factorialOfAAnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//factorial of a number
		int i,fact=1;
		int num=3;
		for(i=1;i<=num;i++)
		{
			fact=fact*i;
		}
		System.out.println("Factorial of "+num+"  is:" +fact);

	}

}
