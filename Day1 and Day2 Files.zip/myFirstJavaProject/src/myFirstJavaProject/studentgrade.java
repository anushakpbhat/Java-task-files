package myFirstJavaProject;

public class studentgrade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Grade of student
		 
		 int marks=425;
		 if(marks>=400)
		 {
			 System.out.println("Student secured 'A' grade");
		 }
		 else if(marks>=300 && marks<=400)
		 {
			 System.out.println("Student secured 'B' grade");
		 }
		 else
		 {
			 System.out.println("Student secured 'C' grade");
		 }

	}

}
