package myFirstJavaProject;

public class sumOfEvenWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int sum=0,c=2;
		while(c<=100)
		{
			if(c%2==0) {
				sum=sum+c;
				c++;
			}
			c++;
		}
		System.out.println("The sum of first 100 even numbers is:"+sum);
		
		
		
		
		int sums=0,n=2;
		do
		{
			if(n%2==0) {
				sums=sums+n;
				n++;
			}
			n++;
		}
		while(n<=100);
		System.out.println("The sum of first 100 even numbers is:"+sums);

	}

}
