package myFirstJavaProject;
import java.util.Scanner;

public class calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//calculator
	 char choice;
	   Scanner s = new Scanner(System.in);
	   System.out.println("Calculator");
	  do {
	   System.out.println("Enter the first number:");
	   int n1=s.nextInt();
	   System.out.println("Enter the second number:");
	   int n2=s.nextInt();
	   System.out.println("Select the Operation:");
	   System.out.println("1.Addition");
	   System.out.println("2.Subtraction");
	   System.out.println("3.Multiplication");
	   System.out.println("4.Division");
	   int i =s.nextInt();
	   if(i==1) {
		   System.out.println("Addition:"+(n1+n2));
	   }
	   else if(i==2) {
		   System.out.println("Subtraction:"+(n1-n2));
	   }
	   else if(i==3) {
		   System.out.println("Multiplication:"+(n1*n2));
	   }
	   else if(i==4) {
		   System.out.println("Division:"+(n1/n2));
	   }
	   
	  
	   System.out.println("Do you want to continue?(y/n)");
	   choice=s.next().charAt(0);
	   }
	  while(choice=='y'||choice=='Y');
		   System.out.println("Thank you!!!");
	  
	   }
	   
	}

//using strings
//System.out.print("Do you want to continue?(yes/no)");
//choice=scan.next();
//}
//while(choice.equals("YES")|| choice.equals("yes"));
//System.out.print("Thank you!!!");
	


