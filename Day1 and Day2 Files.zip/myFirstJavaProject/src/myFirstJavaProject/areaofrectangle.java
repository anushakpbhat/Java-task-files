package myFirstJavaProject;

public class areaofrectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Area of rectangle
		 
		int length=5;
		int breadth=10;
		float area=length*breadth;
		System.out.println("The area of rectangle is:"+area);
		

	}

}
