package myFirstJavaProject;

public class returnMethod {
	
	public int sum(int x) {    //sum of numbers from 1 to 100
		
		int sum=0,i;
		for(i=1;i<=100;i++) {
			sum+=i;
			i++;
		}
		
		return sum;	
	}
	
	public float area(float r) {     //area of circle
	       
		float areas;
		return areas=(float) (3.14*r*r);
	}
	  
	
      public float area(float l,float b) {  //area of rectangle
	       	
		float areass;
		return areass=(float) (l*b);
	}
	        

     public float area1(float s)  //area of square
     {
	float are;
	return are=(float) (s*s);
    }
        
     public int even(int n) {   //Even or odd
    	 if( n%2==0) {
    		System.out.println("Even");
    	 }
    	 else {
    		 
    	 System.out.println("Odd");
    	 }
    	 return n;
     }
     
     
     public int positive(int c) { //positive or negative
    	 if( c>=0) {
    		System.out.println("Positive");
    	 }
    	 else {
    		 
    	 System.out.println("Negative");
    	 }
    	 return c;
     }
     
     
   
	
	
	
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		returnMethod m=new returnMethod();
		int sums=m.sum(0);
		System.out.println(sums);
		
		float a=m.area(6);
		System.out.println("the area of circle is:"+(a));
		float b=m.area(6,2);
		System.out.println("the area of rectangle is:"+(b));
		float c=m.area1(6);
		System.out.println("the area of square is:"+(c));
		
		
		int i=m.even(8);
		System.out.println(i);
		
		int in=m.positive(-8);
		System.out.println(in);
		
		
		

	}

}
