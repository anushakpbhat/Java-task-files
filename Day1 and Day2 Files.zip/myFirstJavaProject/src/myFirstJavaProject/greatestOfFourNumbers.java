package myFirstJavaProject;

public class greatestOfFourNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Greatest of 4 numbers
		 int num1=20,num2=30,num3=10,num4=40;
		 
	     if(num1>num2 && num1>num3 && num1>num4)
		  {
		  	 System.out.println("Num 1 is greater");
		  	 }
		  else if(num2>num3 && num2>num1 && num2>num4)
		  {
		 	 System.out.println("Num 2 is greater");
		  }
		  else if(num3>num4 && num3>num1 && num3>num2)
		  {
		 	 System.out.println("Num 3 is greater");
		  }
		   else 
		  System.out.println("Num 4 is greater");     

	}

}
