package myFirstJavaProject;

public class sumOfOddNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// sum of first 50 odd numbers 
		int summ=0,n;
		for(n=1;n<=50; n++)
		{
			if(n%2!=0) {
				summ=summ+n;	
			}
			
		}
		System.out.println("The sum of first 50 odd numbers is:"+summ);

	}

}
