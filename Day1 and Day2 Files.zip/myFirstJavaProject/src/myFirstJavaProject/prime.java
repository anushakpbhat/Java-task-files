package myFirstJavaProject;

public class prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Prime or not
				int n=0,flag=0;
			    int num=3,i;
				n=num/2;
				if(num==0||num==1) {
					System.out.println(num+ " is not a prime Number");
				}
				else {
					for(i=2;i<=n;i++) {
						if(num%i==0) {
							System.out.println(num+ "is not a prime number");
						    flag=1;
						    break;
						}
					}
					if(flag==0)
					{
						System.out.println(num+ ":is a prime number");
					}
				}

	}

}
