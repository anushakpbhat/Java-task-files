package myFirstJavaProject;
import java.util.Scanner;

public class averageofnumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Average of 5  numbers
		
		Scanner in=new Scanner(System.in);
		System.out.println("First Number:");
		int num1=in.nextInt();
		System.out.println("Second Number:");
		int num2=in.nextInt();
		System.out.println("Third Number:");
		int num3=in.nextInt();
		System.out.println("Fourth Number:");
		int num4=in.nextInt();
		System.out.println("Fifth Number:");
		int num5=in.nextInt();
		System.out.println("The average is:"+(num1+num2+num3+num4+num5)/5);
	
		

	}

}
