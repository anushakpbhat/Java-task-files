package myFirstJavaProject;

public class fibonacciUsingWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//while
		int n1=0,n2=1,n3,count=20,i;
		System.out.print(n1+" "+n2);
		i=2;
		while(i<=count)
		{
			n3=n1+n2;
			System.out.print(" "+n3);
			 n1=n2;
			 n2=n3;
			 i++;
	
		}

		
		 System.out.println();//spacing purpose
		
		//do while
		int num1=0,num2=1,num3,counts=20,n;
		System.out.print(num1+" "+num2);
		n=2;
		do
		{
			num3=num1+num2;
			System.out.print(" "+num3);
			num1=num2;
		    num2=num3;
			n++;
			
			 
			
	
		}
		while(n<=counts);
		
	}

}
