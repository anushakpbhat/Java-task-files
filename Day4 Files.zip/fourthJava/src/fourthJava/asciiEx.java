package fourthJava;

public class asciiEx {

	public static void main(String[] args) {
		for(int i=97;i<=122;i++) {
			System.out.println("The ascii value of "+(char)i+"="+i);
		}

	}

}
//lowercase alphabets
